<?php

include(dirname(__FILE__)."/../../wp-config.php");
include("./gestionBD.php");
$result = $pdo->prepare("SELECT * FROM A_GrupoCliente");
$result->execute();
$datos = $result->fetchAll(PDO::FETCH_ASSOC);
$salida=array(plantilla=>"listarTemplate.html","datos"=>$datos);
$dat= json_encode($datos);
$salida="{\"plantilla\":\"listarTemplate.html\",\"datos\":$dat}";
echo $salida;


?>